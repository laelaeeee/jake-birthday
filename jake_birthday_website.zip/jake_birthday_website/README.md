# Jake's Birthday Surprise 💗

A mobile-friendly, romantic pink-and-white birthday greeting website.

## Preview locally
1. Download and unzip `jake_birthday_website.zip`.
2. Open `index.html` in a modern browser (Chrome, Safari, Firefox, or Edge).
3. Tap **Open your surprise** to reveal the birthday letter, then tap **Make a birthday wish** to reach the animated cake.
4. Tap **Music: Off** to start the gentle original browser-generated melody. Browsers require a tap before playing audio.

## Publish it online for free with GitHub Pages
1. Sign in or create an account at https://github.com/
2. Create a new public repository, for example `jake-birthday`.
3. Upload `index.html` to the repository's root (the top level).
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/(root)`, then click **Save**.
7. Wait a minute or two. GitHub will show a public URL, usually like `https://YOUR-USERNAME.github.io/jake-birthday/`.
8. Open the URL on your phone to test it, then send the link to Jake.

## Customize the message
Open `index.html` in a text editor and find the letter paragraphs in the section with `id="letterSection"`. Replace the wording with your own message. The recipient name is in the page title, welcome heading, and footer.

## Notes
- The background melody is synthesized locally by the browser; no external audio file or tracking is used.
- Music starts only after the visitor taps the music button, due to browser autoplay restrictions.
- The site does not collect or send personal data.
